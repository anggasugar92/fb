require 'test_helper'

class DashboardControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
